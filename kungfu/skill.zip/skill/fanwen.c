// fanwen.c  基础梵文

inherit SKILL;

string type() { return "knowledge"; }

void skill_improved(object me)
{}

