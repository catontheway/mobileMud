//fork.c 基本叉法
inherit SKILL;
