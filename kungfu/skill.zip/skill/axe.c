// axe.c 基本斧法
// Modified by Venus Oct.1997
inherit SKILL;

