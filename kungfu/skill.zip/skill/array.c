// array.c

inherit SKILL;
