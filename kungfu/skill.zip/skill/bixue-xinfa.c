//碧血心法

inherit FORCE;

int valid_enable(string usage) { return usage=="force"; }

int valid_learn(object me)
{
        return 1;
}

int practice_skill(object me)
{
        return notify_fail("碧血心法只能用学的，或是从读书中增加熟练度。\n");
}

string exert_function_file(string func)
{
        return __DIR__"bixue-xinfa/" + func;
}

