// anti-disguise.c 伪装识别技巧

inherit SKILL;

string type() { return "profession"; }

void skill_improved(object me)
{}

