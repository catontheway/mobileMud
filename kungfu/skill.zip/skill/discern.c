// discern.c 辨位之术

inherit SKILL;

string type() { return "profession"; }

void skill_improved(object me)
{}

