// digging.c 掘地之术
 
inherit SKILL;
