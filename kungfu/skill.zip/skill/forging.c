// forging.c 锻造术

inherit SKILL;

string type() { return "profession"; }

void skill_improved(object me)
{}

