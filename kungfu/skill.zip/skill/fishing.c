// fishing.c 钓鱼之术

inherit SKILL;

string type() { return "profession"; }

void skill_improved(object me)
{}

