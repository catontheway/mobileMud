// checking.c 道听途说
// 丐帮特有技能

inherit SKILL;

string type() { return "knowledge"; }
