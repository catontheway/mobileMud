// finger.c 基本指法

inherit SKILL;
