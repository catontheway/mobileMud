// cooking.c 职业技能

inherit SKILL;

void create() { seteuid(getuid()); }

string type() { return "profession"; }

int valid_learn(object me) 
{
	return notify_fail("『烹饪之术』只能从实践中提高。\n");
}

int practice_skill(object me)
{	
	return notify_fail("『烹饪之术』只能从实践中提高。\n");
}
