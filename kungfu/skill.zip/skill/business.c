// 经商之道

inherit SKILL;

string type() { return "profession"; }

void skill_improved(object me)
{
	tell_object(me,"你感觉自己在商海打拼这么多年，终于又上了一层楼了！\n");
}

