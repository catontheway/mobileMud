
// dagger.c

inherit SKILL;
