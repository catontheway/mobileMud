// club.c 基本棍法

inherit SKILL;
