// blade.c 基本刀法

inherit SKILL;
