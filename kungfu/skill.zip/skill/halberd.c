// halberd.c 基本戟法

inherit SKILL;
