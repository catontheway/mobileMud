// Made by ysg
// Data: 1997.10.17

#include <ansi.h>
inherit SKILL;
int valid_learn(object me)
// need more limit here
{
        return 1;
}

int practice_skill(object me)
{
        return notify_fail("道学心法只能用学(learn)的来增加熟练度。\n");
}

string type() { return "knowledge"; }
