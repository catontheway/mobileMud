// cs-skill.c cs技巧

inherit SKILL;

string type() { return "knowledge"; }

void skill_improved(object me)
{}


