// claw.c 基本爪法

inherit SKILL;
