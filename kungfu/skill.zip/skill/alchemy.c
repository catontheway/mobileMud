inherit SKILL;

string type() { return "knowledge"; }
int professional() {return 1;}