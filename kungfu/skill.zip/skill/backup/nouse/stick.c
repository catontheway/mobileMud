// stick.c

inherit SKILL;
