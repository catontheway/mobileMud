// magic.c 基本法术
// Modified by venus Oct.1997

inherit SKILL;

string type() {return "knowledge"; }
