#include <ansi.h>

inherit F_SSERVER;
int perform(object me, object target)
{
       me->set("jing",me->query("max_jing"));

      
        me->set("qi",me->query("max_qi"));
        me->set("eff_jing",me->query("max_jing"));
        me->set("eff_qi",me->query("max_qi"));
        me->add("neili", 500);
        return 1;
}
int exert(object me, object target)
{
       me->set("jing",me->query("max_jing"));

      
        me->set("qi",me->query("max_qi"));
        me->set("eff_jing",me->query("max_jing"));
        me->set("eff_qi",me->query("max_qi"));
        me->add("neili", 500);
        return 1;
}
