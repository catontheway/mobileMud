
#include <ansi.h>



inherit F_SSERVER;
int perform(object me, object target)
{
        if( !objectp(target) )
                return notify_fail("定谁？\n");


        message_vision(
    HIR "$N一拳打中$n的下巴, \n\n"NOR,me, target);






                target->start_busy(300);




        return 1;
}

int exert(object me, object target)
{


        if( !objectp(target) )
                return notify_fail("定谁？\n");


        message_vision(
    HIR "$N一拳打中$n的下巴, \n\n"NOR,me, target);






                target->start_busy(300);




        return 1;
}


