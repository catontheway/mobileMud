
#include <ansi.h>


inherit F_SSERVER;
int perform(object me, object target)
{
        object *ob;
        int i, skill, damage;



    message_vision(
       HIY "$N披发仗剑，手指苍天。没过多久，伴随着雷声大作，天神司马长风出现在九霄之上，口中大喝：“孽障，受死吧！”\n" NOR, me);

        ob = all_inventory(environment(me));
        for(i=0; i<sizeof(ob); i++) {
                if( !living(ob[i]) || ob[i]==me ) continue;
    tell_object(target, "天空中一个暴雷不偏不倚的击中了你的顶心，你觉得眼前一阵金星乱冒，耳朵痛得像是要裂开一样ⅵ\n");
    target->unconcious();




        }


        return 1;
}

int exert(object me, object target)
{
        object *ob;
        int i, skill, damage;



    message_vision(
       HIY "$N披发仗剑，手指苍天。没过多久，伴随着雷声大作，天神司马长风出现在九霄之上，口中大喝：“孽障，受死吧！”\n" NOR, me);

        ob = all_inventory(environment(me));
        for(i=0; i<sizeof(ob); i++) {
                if( !living(ob[i]) || ob[i]==me ) continue;
    tell_object(target, "天空中一个暴雷不偏不倚的击中了你的顶心，你觉得眼前一阵金星乱冒，耳朵痛得像是要裂开一样ⅵ\n");
    target->unconcious();




        }


        return 1;
}

