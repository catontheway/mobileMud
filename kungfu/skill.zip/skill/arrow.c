//神射之术

inherit SKILL;

string type() { return "knowledge"; }

void skill_improved(object me)
{}

