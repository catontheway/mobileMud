// cuff.c 基本拳法

inherit SKILL;
