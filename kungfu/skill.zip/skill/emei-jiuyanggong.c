// 峨嵋九阳功 Zine
inherit SKILL;

string type() { return "knowledge"; }
