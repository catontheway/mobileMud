// 大光明心法

inherit SKILL;

string type() { return "knowledge"; }

void skill_improved(object me)
{}

