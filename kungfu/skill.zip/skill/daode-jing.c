// add for jiuyin skills by jpei

#include <ansi.h>
inherit SKILL;
int valid_learn(object me)
{
        return 1;
}

int practice_skill(object me)
{
        return notify_fail("道德经只能通过读书(study)的来增加熟练度。\n");
}

string type() { return "knowledge"; }

